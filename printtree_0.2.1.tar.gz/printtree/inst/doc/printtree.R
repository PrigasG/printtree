## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(printtree)

## -----------------------------------------------------------------------------
tmp <- tempdir()
demo <- file.path(tmp, "printtree-demo")

# Start fresh

if (dir.exists(demo)) unlink(demo, recursive = TRUE, force = TRUE)

dir.create(demo, recursive = TRUE)
dir.create(file.path(demo, "R"))
dir.create(file.path(demo, "data", "raw"), recursive = TRUE)

file.create(file.path(demo, "R", "hello.R"))
file.create(file.path(demo, "README.md"))
file.create(file.path(demo, ".Rhistory"))


## -----------------------------------------------------------------------------
print_rtree()

## -----------------------------------------------------------------------------
file.create(file.path(demo, "DESCRIPTION"))
subdir <- file.path(demo, "data", "raw")
print_rtree(subdir, project = "root")

## -----------------------------------------------------------------------------
print_rtree(subdir,
project = "root",
root_markers = c(".Rproj", "DESCRIPTION", "_quarto.yml"))


## -----------------------------------------------------------------------------
print_rtree(max_depth = 2)


## -----------------------------------------------------------------------------
print_rtree(demo, max_depth = 1)

## -----------------------------------------------------------------------------
print_rtree(demo, max_depth = 1, count_footer = FALSE)

## -----------------------------------------------------------------------------
file.create(file.path(demo, "debug.log"))
print_rtree(demo, ignore = c("*.log", ".Rhistory"), max_depth = 2)

## -----------------------------------------------------------------------------
print_rtree(demo, ignore = "^README", ignore_type = "regex", max_depth = 1)

## -----------------------------------------------------------------------------
dir.create(file.path(demo, "logs"))
file.create(file.path(demo, "logs", "debug.log"))
print_rtree(demo, ignore = "*.log", prune = TRUE)

## -----------------------------------------------------------------------------
print_rtree(demo, show_hidden = TRUE, max_depth = 2)


## -----------------------------------------------------------------------------
print_rtree(demo, format = "unicode", max_depth = 2)


## ----eval = FALSE-------------------------------------------------------------
# print_rtree(git = TRUE)

## -----------------------------------------------------------------------------
lines <- print_rtree(demo, return_lines = TRUE, quiet = TRUE)
head(lines)

## -----------------------------------------------------------------------------
tree_md <- file.path(tempdir(), "printtree-output", "tree.md")
write_tree(demo, tree_md, format = "md", title = "Demo Tree")

## -----------------------------------------------------------------------------
# Save PNG snapshots 
png_light <- tempfile("tree-light-", fileext = ".png")
png_dark  <- tempfile("tree-dark-",  fileext = ".png")

# Light (white bg, black text)
print_rtree(demo, snapshot = TRUE, snapshot_bg = "white", snapshot_file = png_light)

# Dark (black bg, white text)
print_rtree(demo, snapshot = TRUE, snapshot_bg = "black", snapshot_file = png_dark)



