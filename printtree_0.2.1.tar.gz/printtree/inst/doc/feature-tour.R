## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(printtree)

## ----demo-tree----------------------------------------------------------------
demo <- file.path(tempdir(), "printtree-feature-tour")
if (dir.exists(demo)) unlink(demo, recursive = TRUE, force = TRUE)

dir.create(file.path(demo, "R"), recursive = TRUE)
dir.create(file.path(demo, "data", "raw"), recursive = TRUE)
dir.create(file.path(demo, "logs"), recursive = TRUE)
dir.create(file.path(demo, "empty"), recursive = TRUE)

file.create(file.path(demo, "R", "helpers.R"))
file.create(file.path(demo, "README.md"))
file.create(file.path(demo, "data", "raw", "sales.csv"))
file.create(file.path(demo, "logs", "debug.log"))
file.create(file.path(demo, "test_cache"))

## ----count-summary------------------------------------------------------------
print_rtree(demo, max_depth = 2)

## ----compact-output-----------------------------------------------------------
print_rtree(demo, max_depth = 1, count_footer = FALSE)

## ----glob-ignore--------------------------------------------------------------
print_rtree(demo, ignore = c("*.log", "test_*"), max_depth = 2)

## ----regex-ignore-------------------------------------------------------------
print_rtree(demo, ignore = "^(README|test_)", ignore_type = "regex", max_depth = 1)

## ----prune--------------------------------------------------------------------
print_rtree(demo, ignore = "*.log", prune = TRUE)

## ----quiet-capture------------------------------------------------------------
lines <- print_rtree(demo, return_lines = TRUE, quiet = TRUE)
head(lines, 4)

## ----write-tree---------------------------------------------------------------
tree_md <- file.path(tempdir(), "printtree-feature-tour-output", "tree.md")
write_tree(demo, tree_md, format = "md", title = "Feature Tour Tree")
readLines(tree_md, n = 8)

## ----git-status, eval = nzchar(Sys.which("git"))------------------------------
repo <- file.path(tempdir(), "printtree-feature-tour-git")
if (dir.exists(repo)) unlink(repo, recursive = TRUE, force = TRUE)
dir.create(repo, recursive = TRUE)

system2("git", c("-C", repo, "init"), stdout = FALSE, stderr = FALSE)
system2("git", c("-C", repo, "config", "user.email", "test@example.com"))
system2("git", c("-C", repo, "config", "user.name", "Test User"))

file.create(file.path(repo, "tracked.txt"))
system2("git", c("-C", repo, "add", "tracked.txt"), stdout = FALSE, stderr = FALSE)
system2("git", c("-C", repo, "commit", "-m", "initial"), stdout = FALSE, stderr = FALSE)

writeLines("changed", file.path(repo, "tracked.txt"))
file.create(file.path(repo, "new.txt"))

print_rtree(repo, git = TRUE)

## ----git-status-fallback, eval = !nzchar(Sys.which("git"))--------------------
# print_rtree("path/to/repo", git = TRUE)

